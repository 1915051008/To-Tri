<?php
$con->auth();
$conn=$con->koneksi();
switch (@$_GET['page']){
    case 'add';
break;
case 'edit';
break;
default;
$sql="select * from kue";
$kue=$conn->query($sql);
$conn->close();
$content="views/kue/tampil.php";
include_once 'views/template.php';
}
?>